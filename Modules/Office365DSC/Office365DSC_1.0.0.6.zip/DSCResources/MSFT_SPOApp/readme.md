# Description

This resource allows users to deploy App instances in the
App Catalog.
